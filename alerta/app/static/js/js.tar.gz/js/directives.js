'use strict';

/* Directives */

var alertaDirectives = angular.module('alertaDirectives', []);
